﻿using System;
using System.Data.SqlClient;
using System.Configuration;

namespace EduConnect
{
    public partial class Login : System.Web.UI.Page
    {
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            string connStr = ConfigurationManager.ConnectionStrings["EduConnectDB"].ConnectionString;



            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                string query = "SELECT Role FROM Users WHERE Username=@Username AND PasswordHash=@Password";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);

                    var roleObj = cmd.ExecuteScalar();

                    if (roleObj != null)
                    {
                        string role = roleObj.ToString();

                        // Store login session info
                        Session["Username"] = username;
                        Session["Role"] = role;

                        // Redirect based on role
                        if (role == "Admin")
                            Response.Redirect("AdminDashboard.aspx");
                        else if (role == "Student")
                            Response.Redirect("StudentDashboard.aspx");
                        else
                            Response.Redirect("Default.aspx"); // fallback
                    }
                    else
                    {
                        lblMessage.Text = "Invalid username or password.";
                    }
                }
            }
        }
    }
}
