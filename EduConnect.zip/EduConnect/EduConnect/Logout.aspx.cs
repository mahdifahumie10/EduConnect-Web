﻿using System;

namespace EduConnect
{
    public partial class Logout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session.Clear();       // remove all session data
            Session.Abandon();     // destroy session
            Response.Redirect("Default.aspx"); // redirect to homepage
        }
    }
}
