﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EduConnect
{
    public partial class StudentResults : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["EduConnectDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Ensure student is logged in
            if (Session["Role"] == null || Session["Role"].ToString() != "Student")
            {
                Response.Redirect("Login.aspx");
            }

            if (!IsPostBack)
            {
                BindResults();
            }
        }

        private void BindResults()
        {
            string username = Session["Username"].ToString();

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = @"
                    SELECT Q.QuizID, Q.Question, R.SelectedAnswer, Q.CorrectOption,
                           CASE WHEN R.SelectedAnswer = Q.CorrectOption THEN 'Correct' ELSE 'Incorrect' END AS IsCorrect
                    FROM QuizResults R
                    INNER JOIN Quizzes Q ON R.QuizID = Q.QuizID
                    WHERE R.Username = @Username
                    ORDER BY R.DateTaken DESC";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        gvResults.DataSource = dt;
                        gvResults.DataBind();
                    }
                    else
                    {
                        lblMessage.Text = "No quiz attempts found.";
                    }
                }
            }
        }
    }
}
