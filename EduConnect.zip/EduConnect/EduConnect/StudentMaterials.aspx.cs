﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EduConnect
{
    public partial class StudentMaterials : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["EduConnectDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Only allow logged-in students
            if (Session["Role"] == null || Session["Role"].ToString() != "Student")
            {
                Response.Redirect("Login.aspx");
            }

            if (!IsPostBack)
            {
                BindMaterials();
            }
        }

        private void BindMaterials()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    string query = "SELECT Title, Type, Content FROM Materials ORDER BY CreatedDate DESC";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    rptMaterials.DataSource = dt;
                    rptMaterials.DataBind();
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error loading materials: " + ex.Message;
            }
        }
    }
}
