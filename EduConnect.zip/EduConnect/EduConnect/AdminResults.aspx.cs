﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EduConnect
{
    public partial class AdminResults : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["EduConnectDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Role"] == null || Session["Role"].ToString() != "Admin")
                Response.Redirect("Login.aspx");

            if (!IsPostBack)
                LoadResults();
        }

        private void LoadResults()
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "SELECT StudentUsername, Score, TotalQuestions, DateTaken FROM QuizResults ORDER BY DateTaken DESC";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                    gvResults.DataSource = dt;
                else
                    lblMessage.Text = "No quiz results found.";

                gvResults.DataBind();
            }
        }
    }
}
