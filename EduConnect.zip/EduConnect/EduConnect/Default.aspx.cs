﻿using System;
using System.Web.UI;

namespace EduConnect
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Optional: show logged-in username if available
            if (Session["Username"] != null)
            {
                //lblWelcome.Text = "Welcome, " + Session["Username"].ToString() + "!";
                //lblWelcome.Visible = true;
            }
        }
    }
}

