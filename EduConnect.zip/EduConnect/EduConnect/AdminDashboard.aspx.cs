﻿using System;

namespace EduConnect
{
    public partial class AdminDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Role"] == null || Session["Role"].ToString() != "Admin")
                Response.Redirect("Login.aspx");
        }

        protected void btnMaterials_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminMaterials.aspx");
        }

        protected void btnQuizzes_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminQuiz.aspx");
        }

        protected void btnResults_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminResults.aspx");
        }
    }
}

