﻿using System;
using System.Data.SqlClient;
using System.Configuration;

namespace EduConnect
{
    public partial class Register : System.Web.UI.Page
    {
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text.Trim();

            string passwordHash = password; // for demo only

            string connStr = ConfigurationManager.ConnectionStrings["EduConnectDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                string checkQuery = "SELECT COUNT(*) FROM Users WHERE Username=@Username OR Email=@Email";
                using (SqlCommand cmdCheck = new SqlCommand(checkQuery, conn))
                {
                    cmdCheck.Parameters.AddWithValue("@Username", username);
                    cmdCheck.Parameters.AddWithValue("@Email", email);
                    int exists = (int)cmdCheck.ExecuteScalar();
                    if (exists > 0)
                    {
                        lblMessage.Text = "Username or Email already exists.";
                        return;
                    }
                }

                string insertQuery = "INSERT INTO Users (Username, PasswordHash, Email, Role) VALUES (@Username, @Password, @Email, 'Student')";
                using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", passwordHash);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.ExecuteNonQuery();
                }

                lblMessage.CssClass = "text-success";
                lblMessage.Text = "Registration successful! You can now <a href='Login.aspx'>login</a>.";
                txtUsername.Text = "";
                txtEmail.Text = "";
                txtPassword.Text = "";
            }
        }
    }
}
