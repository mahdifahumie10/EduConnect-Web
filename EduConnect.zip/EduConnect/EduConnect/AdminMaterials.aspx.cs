﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EduConnect
{
    public partial class AdminMaterials : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["EduConnectDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Role"] == null || Session["Role"].ToString() != "Admin")
                Response.Redirect("Login.aspx");

            if (!IsPostBack)
                BindMaterials();
        }

        private void BindMaterials()
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "SELECT MaterialID, Title, Type, Content FROM Materials ORDER BY CreatedDate DESC";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gvMaterials.DataSource = dt;
                gvMaterials.DataBind();
            }
        }

        protected void btnAddMaterial_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "INSERT INTO Materials (Title, Type, Content, CreatedDate) VALUES (@Title, @Type, @Content, GETDATE())";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Title", txtTitle.Text.Trim());
                    cmd.Parameters.AddWithValue("@Type", ddlType.SelectedValue);
                    cmd.Parameters.AddWithValue("@Content", txtContent.Text.Trim());
                    cmd.ExecuteNonQuery();
                }
            }

            lblMessage.Text = "Material added successfully!";
            txtTitle.Text = "";
            txtContent.Text = "";
            ddlType.SelectedIndex = 0;

            BindMaterials(); // refresh grid
        }

        protected void gvMaterials_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
        {
            int materialID = Convert.ToInt32(gvMaterials.DataKeys[e.RowIndex].Value);

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "DELETE FROM Materials WHERE MaterialID=@MaterialID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaterialID", materialID);
                    cmd.ExecuteNonQuery();
                }
            }

            BindMaterials(); // refresh grid
        }
    }
}

