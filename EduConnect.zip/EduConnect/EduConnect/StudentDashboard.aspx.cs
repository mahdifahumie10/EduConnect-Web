﻿using System;

namespace EduConnect
{
    public partial class StudentDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Ensure only logged-in students can access this page
            if (Session["Role"] == null || Session["Role"].ToString() != "Student")
                Response.Redirect("Login.aspx");

            if (!IsPostBack)
            {
                lblUsername.Text = Session["Username"].ToString();
            }
        }

        protected void btnMaterials_Click(object sender, EventArgs e)
        {
            Response.Redirect("StudentMaterials.aspx");
        }

        protected void btnQuiz_Click(object sender, EventArgs e)
        {
            Response.Redirect("StudentQuiz.aspx");
        }

        protected void btnResults_Click(object sender, EventArgs e)
        {
            Response.Redirect("StudentQuizHistory.aspx");
        }
    }
}
