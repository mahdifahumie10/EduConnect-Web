﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EduConnect
{
    public partial class SiteMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["Username"] != null)
                {
                    phGuest.Visible = false; // hide Register/Login
                    phUser.Visible = true;   // show user links

                    // Show admin links only if role is Admin
                    if (Session["Role"] != null && Session["Role"].ToString() == "Admin")
                    {
                        phAdmin.Visible = true;
                    }
                    else
                    {
                        phAdmin.Visible = false;
                    }
                }
                else
                {
                    phGuest.Visible = true;  // show Register/Login
                    phUser.Visible = false;  // hide user links
                    phAdmin.Visible = false; // hide admin links
                }
            }
        }

    }
}