﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EduConnect
{
    public partial class AdminQuiz : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["EduConnectDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Only admins can access
            if (Session["Role"] == null || Session["Role"].ToString() != "Admin")
                Response.Redirect("Login.aspx");

            if (!IsPostBack)
                BindQuizzes();
        }

        private void BindQuizzes()
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = @"SELECT QuestionID, QuizID, QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption 
                                 FROM QuizQuestions 
                                 ORDER BY QuizID DESC";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                gvQuizzes.DataSource = dt;
                gvQuizzes.DataBind();
            }
        }

        protected void btnAddQuiz_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = @"INSERT INTO QuizQuestions (QuizID, QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption) 
                                 VALUES (@QuizID, @Question, @A, @B, @C, @D, @Correct)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // You can set QuizID to NULL if you are not using it, or set dynamically if multiple quizzes
                    cmd.Parameters.AddWithValue("@QuizID", DBNull.Value);
                    cmd.Parameters.AddWithValue("@Question", txtQuestion.Text.Trim());
                    cmd.Parameters.AddWithValue("@A", txtOptionA.Text.Trim());
                    cmd.Parameters.AddWithValue("@B", txtOptionB.Text.Trim());
                    cmd.Parameters.AddWithValue("@C", txtOptionC.Text.Trim());
                    cmd.Parameters.AddWithValue("@D", txtOptionD.Text.Trim());
                    cmd.Parameters.AddWithValue("@Correct", ddlCorrectOption.SelectedValue);
                    cmd.ExecuteNonQuery();
                }
            }

            lblMessage.Text = "Quiz question added successfully!";
            txtQuestion.Text = "";
            txtOptionA.Text = "";
            txtOptionB.Text = "";
            txtOptionC.Text = "";
            txtOptionD.Text = "";
            ddlCorrectOption.SelectedIndex = 0;

            BindQuizzes();
        }

        protected void gvQuizzes_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
        {
            int questionID = Convert.ToInt32(gvQuizzes.DataKeys[e.RowIndex].Value);

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "DELETE FROM QuizQuestions WHERE QuestionID=@QuestionID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@QuestionID", questionID);
                    cmd.ExecuteNonQuery();
                }
            }

            BindQuizzes();
            lblMessage.Text = "Quiz question deleted successfully!";
        }
    }
}
