﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EduConnect
{
    public partial class StudentQuizHistory : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["EduConnectDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Ensure student is logged in
            if (Session["Role"] == null || Session["Role"].ToString() != "Student")
            {
                Response.Redirect("Login.aspx");
                return;
            }

            if (!IsPostBack)
                LoadQuizHistory();
        }
        private void LoadQuizHistory()
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // Get the UserID of the logged-in student
                SqlCommand cmdUser = new SqlCommand("SELECT UserID FROM Users WHERE Username=@Username", conn);
                cmdUser.Parameters.AddWithValue("@Username", Session["Username"].ToString());
                object userIdObj = cmdUser.ExecuteScalar();

                if (userIdObj == null)
                {
                    lblMessage.Text = "Student not identified.";
                    return;
                }

                int studentID = Convert.ToInt32(userIdObj);

                // Fetch quiz history for this student
                string query = @"
                SELECT QuizID, SelectedOption, IsCorrect, TakenDate
                FROM StudentResults
                WHERE StudentID = @StudentID
                ORDER BY TakenDate DESC";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@StudentID", studentID);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    rptHistory.DataSource = dt;
                    rptHistory.DataBind();
                }
                else
                {
                    lblMessage.Text = "You haven't completed any quizzes yet.";
                }
            }
        }

    }
}

