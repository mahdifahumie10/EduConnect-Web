﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;

namespace EduConnect
{
    public partial class StudentQuiz : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["EduConnectDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Only students can access
            if (Session["Role"] == null || Session["Role"].ToString() != "Student")
                Response.Redirect("Login.aspx");

            if (!IsPostBack)
                BindQuizzes();
        }

        private void BindQuizzes()
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                // Pull questions from QuizQuestions table
                string query = @"
                    SELECT QuestionID, QuizID, QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption
                    FROM QuizQuestions
                    ORDER BY QuizID, QuestionID";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                rptQuizzes.DataSource = dt;
                rptQuizzes.DataBind();
            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int totalQuestions = rptQuizzes.Items.Count;
            int score = 0;

            // Get StudentID from Users table
            int studentID;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmdStudent = new SqlCommand("SELECT UserID FROM Users WHERE Username=@Username", conn);
                cmdStudent.Parameters.AddWithValue("@Username", Session["Username"].ToString());
                object result = cmdStudent.ExecuteScalar();
                if (result == null)
                {
                    lblMessage.Text = "Student not found.";
                    return;
                }
                studentID = Convert.ToInt32(result);
            }

            // Loop through each question in the repeater
            foreach (RepeaterItem item in rptQuizzes.Items)
            {
                HiddenField hfQuestionID = (HiddenField)item.FindControl("hfQuestionID");
                HiddenField hfCorrectOption = (HiddenField)item.FindControl("hfCorrectOption");

                RadioButton rdoA = (RadioButton)item.FindControl("rdoA");
                RadioButton rdoB = (RadioButton)item.FindControl("rdoB");
                RadioButton rdoC = (RadioButton)item.FindControl("rdoC");
                RadioButton rdoD = (RadioButton)item.FindControl("rdoD");

                string selected = "";
                if (rdoA.Checked) selected = "A";
                else if (rdoB.Checked) selected = "B";
                else if (rdoC.Checked) selected = "C";
                else if (rdoD.Checked) selected = "D";

                if (selected == hfCorrectOption.Value)
                    score++;

                // Save individual answer into StudentResults
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    string insertQuery = @"
                INSERT INTO StudentResults (StudentID, QuizID, SelectedOption, IsCorrect)
                VALUES (@StudentID, @QuizID, @SelectedOption, @IsCorrect)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@StudentID", studentID);
                        cmd.Parameters.AddWithValue("@QuizID", Convert.ToInt32(hfQuestionID.Value));
                        cmd.Parameters.AddWithValue("@SelectedOption", selected);
                        cmd.Parameters.AddWithValue("@IsCorrect", (selected == hfCorrectOption.Value ? 1 : 0));
                        cmd.ExecuteNonQuery();
                    }
                }
            }

            lblMessage.Text = $"You scored {score} out of {totalQuestions}.";
        }


    }
}



